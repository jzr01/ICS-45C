#include <iostream>
using namespace std;

class Triangle : public Shape
{
  protected:
    int base;
    int height;
  public:
    Triangle(int x, int y, string n, int b, int h)
      :Shape(x,y,n),base(b),height(h)
      {
      }
    
    virtual double area()
    {
      return base*height/2.0;
    }

    virtual void draw()
    {
      if (base % 2 == 1)
      {
        for (int i = 0; i < height; i++)
        {
          for (int j =0; j < base; j++)
          {
            if (i == 0)
            {
              if (j < (base -1)/2)
              {
                cout << " ";
              }else if (j == (base-1)/2)
              {
                cout << "*";
              }else
              {
                cout << " ";
              }
            }else if(i == height-1)
            {
              cout << "*";
            }else
            {
              if (j == height-i-1 | j == base - height + i)
              {
                cout << "*";
              }else
              {
                cout << " ";
              }
            }
        }
        cout << endl;
      }
      }
      else
      {
        for (int i = 0; i < height; i++)
        {
          for (int j =0; j < base; j++)
          {
            if (i == 0)
            {
              if (j < base/2-1)
              {
                cout << " ";
              }
              else if (j == base/2-1 | j == base/2 )
              {
                cout << "*";
              }
              else
              {
                cout << " ";
              }
            }
            else if(i == height-1)
            {
              cout << "*";
            }else
            {
              if (j == height-i-1 | j == base - height + i)
              {
                cout << "*";
              }else
              {
                cout << " ";
              }
            }
        }
        cout << endl;
      }
    }
    }
};