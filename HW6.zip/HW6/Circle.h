#include <iostream>
using namespace std;
#include "Shape.h"

class Circle : public Shape
{
  private:
    const double PI = 3.14159;
  protected:
    double radius;
  public:
    Circle(int x, int y, string n, double r)
      :Shape(x,y,n),radius(r)
    {
    }

    virtual double area()
    {
      return PI*radius*radius;
    }
    
    virtual void draw()
    {
      for (int i = 0; i < 2*radius+1; i++)
      {
        for (int j = 0; j < 2*radius+1; j++)
        {
          double dis = (i-radius)*(i-radius)+(j-radius)*(j-radius);
          if (dis - radius*radius <= 0.1 && dis - radius*radius >= -0.1 )
          {
            cout << "*";
          }else
          {
            cout << " ";
          }
        }
        cout << endl;
      }
    }
};