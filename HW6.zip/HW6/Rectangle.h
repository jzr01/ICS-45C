#include <iostream>
using namespace std;

class Rectangle : public Shape
{
  private:
    double length;
    double width;
  public:
    Rectangle(int x, int y, string n, double l, double w)
      :Shape::Shape(x,y,n),length(l),width(w)
    {
    }

    virtual double area()
    {
      return width*length;
    }

    virtual void draw()
    {
      for(int i = 0; i < length; i++)
      {
        for (int j = 0; j < width; j++)
        {
          if (i == 0 or i == length-1)
          {
            cout << "*";
          }else
          {
            if (j == 0 or j == width -1)
            {
              cout << "*";
            }else
            {
              cout << " ";
            }
          }
        }  
        cout << endl;
      }
    }
};